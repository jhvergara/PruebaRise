Commercial use Frobidden.
This font is free for personnal use.

To contact the author of the font:
www.cuttyfruty.com
jellyka@gmail.com

------------------------------------------------

Usage commercial interdit.
Cette Police d'�criture est gratuite pour usage personnel.

Pour contacter l'auteure de cette police:
www.cuttyfruty.com
jellyka@gmail.com