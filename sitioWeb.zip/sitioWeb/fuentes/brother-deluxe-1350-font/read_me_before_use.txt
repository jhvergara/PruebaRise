 _______                                                                
(_______)          _                                                _   
 _____ ___  ____ _| |_ ___   ____ _____ ____  _____   ____  _____ _| |_ 
|  ___) _ \|  _ (_   _) _ \ / ___|____ |    \(____ | |  _ \| ___ (_   _)
| |  | |_| | | | || || |_| | |   / ___ | | | / ___ |_| | | | ____| | |_ 
|_|   \___/|_| |_| \__)___/|_|   \_____|_|_|_\_____(_)_| |_|_____)  \__)


You have downloaded a font made by Mr.Fisk (M.Larsson)
The font is shareware.

Use it for commercial things? CONTACT ME! :

mr.fisk@gmail.com or
go to http://fontorama.net


- I N F O R M A T I O N - Read it!

TERMS & CONDITIONS
Information : shareware use & commercial use.

SHAREWARE FONT USAGE : The definition of a shareware font is that you may download and use the MR.FISK FONT / FONTS for whatever you like, but you can�t use them for commercial things, if you want to do that you must purchase a font-license for Commercial Use

FONT FOR COMMERCIAL USE

When you pay for this software, you receive a limited license. If you use this software to design certain types of things, you may be required to pay an additional license fee. Examples of uses that require an additional license include the following:

� Packaging for nationally distributed consumer goods
� Television, motion picture, electronic or print advertisements
for nationally distributed consumer goods
� Motion picture titles or credits
� Television program titles or credits
� Book or sound recording packaging
� Business identity use
� Brand identity use
� Use by a publication with a circulation in excess
of 10,000 copies per issue
� Scrapbooking products featuring individual letters and/or alphabets.

Please note; that the above mentioned only constitute examples of use that requires an additional license. These examples does not represent any limitation or delimitation of such use.

If you want to buy a MR.FISK Font limited license � please contact a representative HERE. http://fontorama.net/contactx/

If you need to buy, or there should be any reasonable ground to suspect that you are in need of, a MR.FISK Font additional license � please contact a representative HERE : http://fontorama.net/contactx/

BREACH OF TERMS OF USE

Any use in violation of the above terms, including but not limited to licensed use, modifications, or through any neglection of obtaining a license (limited or additional as required) for commercial use, paid in full before any usage of the product, will, accordingly to this information, published by MR.FISK FONTS, within reach of the public domain, act as a contracting party admission, where the user, also liable for indirect damages as well as direct damages, is to pay for any such damages (as of 2009; EUR 10,000 for any indirect damage) to:  MR.FISK (Mike Larsson).

COPYRIGHT NOTICE

The copying of this and all other copyrighted software is prohibited. You may, however, make one copy of the software for backup purposes. This license does not permit use of the software by your subsidiaries or affiliates. Any modifications of the source code of this software is strictly prohibited. MR.FISK FONTS � Fontorama.net explicitly reserves the right to create derivative works based on this software. MR.FISK FONTS � Fontorama.net retains all title, copyright, trademark and other proprietary rights in this software, backup copies, and documentation. By using this software you acknowledge our proprietary interest in and ownership of this software and agree to use this software in accordance with the terms of this license, or otherwise in accordance with the above stated contracting party admission.